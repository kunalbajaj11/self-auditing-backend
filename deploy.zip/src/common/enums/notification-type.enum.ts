export enum NotificationType {
  ACCRUAL_REMINDER = 'accrual_reminder',
  OCR_PENDING = 'ocr_pending',
  BUDGET_ALERT = 'budget_alert',
  SYSTEM = 'system',
}

