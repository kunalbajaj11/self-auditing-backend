export enum AccrualStatus {
  PENDING_SETTLEMENT = 'pending_settlement',
  SETTLED = 'settled',
  AUTO_SETTLED = 'auto_settled',
}

