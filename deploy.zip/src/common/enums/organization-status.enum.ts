export enum OrganizationStatus {
  ACTIVE = 'active',
  INACTIVE = 'inactive',
}

