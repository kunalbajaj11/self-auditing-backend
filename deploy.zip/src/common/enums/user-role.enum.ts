export enum UserRole {
  SUPERADMIN = 'superadmin',
  ADMIN = 'admin',
  ACCOUNTANT = 'accountant',
  APPROVER = 'approver',
  AUDITOR = 'auditor',
  EMPLOYEE = 'employee',
}

