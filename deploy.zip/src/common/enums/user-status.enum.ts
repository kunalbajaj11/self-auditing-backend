export enum UserStatus {
  ACTIVE = 'active',
  INACTIVE = 'inactive',
}

