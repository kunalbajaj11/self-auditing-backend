export enum ExpenseStatus {
  PENDING = 'pending',
  APPROVED = 'approved',
  SETTLED = 'settled',
  AUTO_SETTLED = 'auto_settled',
}

