export enum ExpenseSource {
  MANUAL = 'manual',
  OCR = 'ocr',
}

