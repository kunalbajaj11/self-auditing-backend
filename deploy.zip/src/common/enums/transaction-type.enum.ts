export enum TransactionType {
  CREDIT = 'credit',
  DEBIT = 'debit',
}

