export enum NotificationChannel {
  EMAIL = 'email',
  INAPP = 'inapp',
  SMS = 'sms',
}

