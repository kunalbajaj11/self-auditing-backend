export enum LicenseKeyStatus {
  ACTIVE = 'active',
  CONSUMED = 'consumed',
  EXPIRED = 'expired',
  REVOKED = 'revoked',
}

