import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OcrService } from './ocr.service';
import { OcrController } from './ocr.controller';
import { CategoryDetectionService } from './category-detection.service';
import { Category } from '../../entities/category.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Category])],
  providers: [OcrService, CategoryDetectionService],
  controllers: [OcrController],
  exports: [OcrService],
})
export class OcrModule {}

