import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FileStorageService } from './file-storage.service';
import { AttachmentsController } from './attachments.controller';
import { Attachment } from '../../entities/attachment.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Attachment])],
  providers: [FileStorageService],
  controllers: [AttachmentsController],
  exports: [FileStorageService],
})
export class AttachmentsModule {}

